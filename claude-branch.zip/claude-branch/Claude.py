"""
Claude.py — Cross-Channel Social Engineering Email Reader
==========================================================
Reads .txt email files from the Email/ folder, displays their
contents, and flags common social engineering indicators.

Part of the project:
  Defending Against Cross-Channel Social Engineering
  through Agentic Frameworks
"""

import os
import re


# ── Social Engineering Indicator Keywords ─────────────────────────────────────

SE_INDICATORS = {
    "urgency":      ["urgent", "immediately", "within 24 hours", "expires",
                     "asap", "right away", "act now", "limited time",
                     "closes tomorrow", "right now"],
    "authority":    ["ceo", "it security", "human resources", "microsoft",
                     "usps", "irs", "hr department", "management", "help desk"],
    "threat":       ["account will be locked", "suspended", "compromised",
                     "returned to sender", "legal action", "penalty",
                     "lose access", "blocked"],
    "credential":   ["verify your identity", "username and password",
                     "ssn", "social security", "confirm your password",
                     "credit card", "bank account", "routing"],
    "suspicious_link": ["http://", "trackng", "microsofft", "secure.net",
                        "hrportal.net", "corp.com"],
}


def detect_se_indicators(content: str) -> dict:
    """
    Scan email content for social engineering red flags.
    Returns a dict of triggered categories and matched phrases.
    """
    content_lower = content.lower()
    findings = {}
    for category, keywords in SE_INDICATORS.items():
        matched = [kw for kw in keywords if kw.lower() in content_lower]
        if matched:
            findings[category] = matched
    return findings


def read_email_files(folder_name: str = "Email") -> list:
    """
    Read all .txt files from the given folder in numeric order.
    Displays content and social engineering analysis for each email.
    Returns a list of dicts: {filename, content, se_flags}.
    """
    if not os.path.exists(folder_name):
        print(f"Error: Folder '{folder_name}' not found.")
        print(f"  → Make sure the '{folder_name}/' directory exists "
              f"in the same location as this script.")
        return []

    txt_files = [f for f in os.listdir(folder_name) if f.endswith(".txt")]

    if not txt_files:
        print(f"No .txt files found in '{folder_name}'.")
        return []

    def extract_number(filename: str) -> float:
        match = re.search(r"(\d+)", filename)
        return int(match.group(1)) if match else float("inf")

    txt_files.sort(key=extract_number)

    emails = []

    for filename in txt_files:
        filepath = os.path.join(folder_name, filename)
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()

        se_flags = detect_se_indicators(content)

        emails.append({
            "filename": filename,
            "content":  content,
            "se_flags": se_flags,
        })

    # ── Display ───────────────────────────────────────────────────────────────
    print(f"\nFound {len(emails)} email(s) in '{folder_name}/'\n")

    for i, email in enumerate(emails, start=1):
        print("=" * 60)
        print(f"  Email {i}: {email['filename']}")
        print("=" * 60)
        print(email["content"])

        # SE analysis
        if email["se_flags"]:
            print("  ⚠️  SOCIAL ENGINEERING INDICATORS DETECTED:")
            for category, matches in email["se_flags"].items():
                label = category.replace("_", " ").title()
                print(f"     [{label}] → {', '.join(matches)}")
        else:
            print("  ✅  No obvious social engineering indicators found.")

        print()

    print(f"Total emails read: {len(emails)}")
    return emails


# ── Entry Point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    emails = read_email_files()
